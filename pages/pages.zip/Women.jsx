import React from 'react';

const Women = () => {
    return (
        <div>
            <h1>Women's Collection</h1>
            <p>Explore our latest collection for women.</p>
        </div>
    );
};

export default Women;