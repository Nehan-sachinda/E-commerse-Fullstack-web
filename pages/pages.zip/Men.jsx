import React from 'react';

const Men = () => {
    return (
        <div>
            <h1>Men's Collection</h1>
            <p>Explore our latest collection for men.</p>
        </div>
    );
};

export default Men;